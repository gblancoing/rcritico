PAQUETE DE DESPLIEGUE A PRODUCCIÓN
==================================

Versión: 1.0.0
Fecha: 2025-12-23 01:03:39

Archivos incluidos: 16

INSTRUCCIONES:
1. Leer DEPLOY_PRODUCCION.md para instrucciones detalladas
2. Hacer backup de la base de datos
3. Ejecutar scripts SQL o PHP para actualizar BD
4. Subir archivos manteniendo estructura de directorios
5. Ejecutar: composer install
6. Verificar permisos

