# Paquete de Despliegue a Producción - Mejoras de Reportes y Visualización

**Fecha:** 2025-12-23  
**Versión:** 1.0.0

## 📦 Archivos Incluidos en el Paquete

### Nuevos Archivos

#### 1. Visualización de Archivos Office
- `api/view_office.php` - Endpoint para visualizar archivos Word, Excel, PowerPoint

#### 2. Sistema de Informes Stockholders
- `api/stockholders/informes.php` - API CRUD para gestión de informes
- `api/stockholders/asociar_reporte.php` - API para asociar reportes ejecutivos
- `api/stockholders/crear_tabla.php` - Script para crear tabla `informes_stockholders`
- `api/stockholders/agregar_columna_parametros.php` - Script para agregar columna `parametros_reporte`

#### 3. Scripts de Base de Datos
- `api/database/create_informes_stockholders_table.sql` - SQL para crear tabla
- `api/database/add_parametros_informes.sql` - SQL para agregar columna de parámetros

#### 4. Componentes Frontend
- `src/components/GestorArchivos.js` - Mejorado para visualizar archivos Office
- `src/analisis/InformesStockholders.js` - Sistema completo de gestión de informes con personalización

### Archivos Modificados

#### 1. Generación de Reportes
- `api/dashboard/generar_reporte_pdf.php` - Reporte PDF profesional con personalización
- `api/dashboard/generar_reporte_html.php` - Vista previa HTML moderna y ejecutiva

#### 2. Dependencias
- `composer.json` - Agregada dependencia `tecnickcom/tcpdf`

---

## 🚀 Instrucciones de Instalación

### Paso 1: Backup de Base de Datos
```sql
-- Hacer backup de la base de datos antes de continuar
```

### Paso 2: Actualizar Base de Datos

#### Opción A: Ejecutar Scripts SQL Manualmente
1. Ejecutar `api/database/create_informes_stockholders_table.sql` en phpMyAdmin o cliente MySQL
2. Ejecutar `api/database/add_parametros_informes.sql` en phpMyAdmin o cliente MySQL

#### Opción B: Usar Scripts PHP Automáticos
1. Acceder a: `http://tu-dominio/rcritico/api/stockholders/crear_tabla.php`
2. Acceder a: `http://tu-dominio/rcritico/api/stockholders/agregar_columna_parametros.php`

### Paso 3: Instalar Dependencias PHP
```bash
cd /ruta/a/rcritico
composer install
# O si TCPDF no está instalado:
composer require tecnickcom/tcpdf
```

### Paso 4: Subir Archivos
Subir todos los archivos del paquete manteniendo la estructura de directorios:
```
rcritico/
├── api/
│   ├── dashboard/
│   │   ├── generar_reporte_pdf.php
│   │   └── generar_reporte_html.php
│   ├── stockholders/
│   │   ├── informes.php
│   │   ├── asociar_reporte.php
│   │   ├── crear_tabla.php
│   │   └── agregar_columna_parametros.php
│   ├── database/
│   │   ├── create_informes_stockholders_table.sql
│   │   └── add_parametros_informes.sql
│   └── view_office.php
├── src/
│   ├── components/
│   │   └── GestorArchivos.js
│   └── analisis/
│       └── InformesStockholders.js
└── composer.json
```

### Paso 5: Verificar Permisos
```bash
# Asegurar que los directorios tengan permisos correctos
chmod 755 api/
chmod 755 api/dashboard/
chmod 755 api/stockholders/
chmod 644 api/dashboard/*.php
chmod 644 api/stockholders/*.php
```

### Paso 6: Verificar Instalación
1. Verificar tabla creada: `http://tu-dominio/rcritico/api/stockholders/debug_error.php`
2. Probar generación de PDF: `http://tu-dominio/rcritico/api/dashboard/test_pdf_simple.php`
3. Verificar que el componente de informes carga correctamente

---

## ✨ Mejoras Implementadas

### 1. Visualización de Archivos Office
- ✅ Visualización de Word (.doc, .docx)
- ✅ Visualización de Excel (.xls, .xlsx)
- ✅ Visualización de PowerPoint (.ppt, .pptx)
- ✅ Mensajes informativos para localhost
- ✅ Fallback a descarga si el visor no funciona

### 2. Sistema de Informes Ejecutivos
- ✅ CRUD completo de informes stockholders
- ✅ Personalización de reportes (secciones, nivel de detalle, formato)
- ✅ Asociación de reportes ejecutivos a informes
- ✅ Vista previa HTML moderna y profesional
- ✅ Generación de PDF profesional

### 3. Reportes PDF/HTML Mejorados
- ✅ Diseño profesional con colores CODELCO
- ✅ Vista previa HTML antes de generar PDF
- ✅ Personalización de secciones incluidas
- ✅ Barras de progreso y badges
- ✅ Diseño compacto y optimizado para impresión
- ✅ Manejo robusto de errores

### 4. Mejoras Técnicas
- ✅ Manejo correcto de puertos (3000 vs 80)
- ✅ Headers anti-caché mejorados
- ✅ Limpieza de buffer de salida
- ✅ Logging mejorado para debugging
- ✅ Validación de datos mejorada

---

## 🔧 Configuración Requerida

### PHP
- PHP 7.4 o superior
- Extensión PDO con MySQL
- Extensión GD para imágenes
- Composer instalado

### Base de Datos
- MySQL 5.7 o superior
- Tabla `proyectos` debe existir
- Tabla `carpetas` debe existir
- Tabla `carpeta_linea_base` debe existir

### Servidor Web
- Apache o Nginx
- Mod_rewrite habilitado (si es necesario)
- Permisos de escritura en directorios de logs

---

## 🐛 Solución de Problemas

### Error: "TCPDF no está disponible"
```bash
composer require tecnickcom/tcpdf
```

### Error: "La tabla informes_stockholders no existe"
Ejecutar: `http://tu-dominio/rcritico/api/stockholders/crear_tabla.php`

### Error: "Columna parametros_reporte no existe"
Ejecutar: `http://tu-dominio/rcritico/api/stockholders/agregar_columna_parametros.php`

### PDF sale en blanco
1. Verificar logs: `error_log_pdf.txt`
2. Verificar permisos de archivos
3. Verificar que no haya output previo antes de generar PDF
4. Verificar que TCPDF esté instalado correctamente

### Archivos Office no se visualizan
- En producción, los visores externos funcionan correctamente
- En localhost, usar opción "Descargar"

---

## 📝 Notas Importantes

1. **Backup**: Siempre hacer backup antes de desplegar
2. **Testing**: Probar en ambiente de staging antes de producción
3. **Caché**: Limpiar caché del navegador después del despliegue
4. **Logs**: Revisar `error_log_pdf.txt` si hay problemas
5. **Composer**: Asegurar que `vendor/` esté en `.gitignore` pero presente en producción

---

## 🔄 Rollback

Si necesitas revertir los cambios:

1. Restaurar backup de base de datos
2. Eliminar archivos nuevos:
   - `api/view_office.php`
   - `api/stockholders/*.php`
   - `api/database/*.sql`
3. Restaurar versiones anteriores de:
   - `api/dashboard/generar_reporte_pdf.php`
   - `api/dashboard/generar_reporte_html.php`
   - `src/components/GestorArchivos.js`
   - `src/analisis/InformesStockholders.js`

---

## 📞 Soporte

Para problemas o consultas, revisar:
- Logs de error: `error_log_pdf.txt`
- Logs de ejecución: `pdf_execution_log.txt`
- Scripts de diagnóstico: `api/stockholders/debug_error.php`

---

**Desarrollado para:** Sistema de Control de Riesgos Críticos - CODELCO  
**Fecha de despliegue:** 2025-12-23

