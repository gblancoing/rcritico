<?php
/**
 * Script de verificación de versión y cambios en producción
 * Verifica que los archivos modificados estén presentes y tengan los cambios correctos
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$resultado = [
    'success' => true,
    'fecha_verificacion' => date('Y-m-d H:i:s'),
    'archivos' => [],
    'errores' => []
];

// Archivos a verificar
$archivos_a_verificar = [
    'api/archivos/carpeta_linea_base.php',
    'api/archivos/carpeta_linea_base_mitigadores.php'
];

// Patrones que deben estar presentes (indicadores de la nueva versión)
$patrones_esperados = [
    'SET SESSION sql_mode',
    'Estrategia robusta: intentar con AUTO_INCREMENT',
    'INSERT con ID explícito'
];

foreach ($archivos_a_verificar as $archivo) {
    $ruta_completa = __DIR__ . '/' . str_replace('api/', '', $archivo);
    $info_archivo = [
        'archivo' => $archivo,
        'existe' => file_exists($ruta_completa),
        'fecha_modificacion' => null,
        'tamaño' => null,
        'patrones_encontrados' => [],
        'version_correcta' => false
    ];
    
    if ($info_archivo['existe']) {
        $info_archivo['fecha_modificacion'] = date('Y-m-d H:i:s', filemtime($ruta_completa));
        $info_archivo['tamaño'] = filesize($ruta_completa);
        
        // Leer contenido del archivo
        $contenido = file_get_contents($ruta_completa);
        
        // Verificar patrones
        foreach ($patrones_esperados as $patron) {
            if (strpos($contenido, $patron) !== false) {
                $info_archivo['patrones_encontrados'][] = $patron;
            }
        }
        
        // Considerar versión correcta si tiene al menos 2 de los 3 patrones
        $info_archivo['version_correcta'] = count($info_archivo['patrones_encontrados']) >= 2;
        
        if (!$info_archivo['version_correcta']) {
            $resultado['errores'][] = "El archivo $archivo no tiene la versión correcta. Patrones encontrados: " . implode(', ', $info_archivo['patrones_encontrados']);
            $resultado['success'] = false;
        }
    } else {
        $resultado['errores'][] = "El archivo $archivo no existe en: $ruta_completa";
        $resultado['success'] = false;
    }
    
    $resultado['archivos'][] = $info_archivo;
}

// Información adicional del sistema
$resultado['sistema'] = [
    'php_version' => phpversion(),
    'directorio_actual' => __DIR__,
    'servidor' => $_SERVER['SERVER_NAME'] ?? 'desconocido',
    'timestamp' => time()
];

echo json_encode($resultado, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

