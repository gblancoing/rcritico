<?php
// Redirección para mantener compatibilidad con rutas antiguas
require_once __DIR__ . '/proyectos/editar_centro_costo.php';
?>

