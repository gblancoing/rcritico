<?php
// Redirección para mantener compatibilidad con rutas antiguas
require_once __DIR__ . '/auth/reset_password.php';
?>

