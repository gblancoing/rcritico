<?php
// Redirección para mantener compatibilidad con rutas antiguas
require_once __DIR__ . '/utils/gemini_chat.php';
?>
