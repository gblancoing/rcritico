<?php
/**
 * Script definitivo para corregir AUTO_INCREMENT en carpeta_linea_base
 * Verifica y corrige la estructura completa
 */

header('Content-Type: application/json; charset=utf-8');

if (ob_get_level()) {
    ob_clean();
}

require_once __DIR__ . '/config.php';

$dbConfig = getDbConfig();
$dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset=utf8mb4";
$username = $dbConfig['user'];
$password = $dbConfig['pass'];
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
    
    $resultado = [
        'fecha' => date('Y-m-d H:i:s'),
        'acciones' => [],
        'errores' => []
    ];
    
    // 1. Obtener el máximo ID
    $stmt_max = $pdo->query("SELECT COALESCE(MAX(id), 0) as max_id FROM carpeta_linea_base");
    $max_result = $stmt_max->fetch(PDO::FETCH_ASSOC);
    $next_id = intval($max_result['max_id']) + 1;
    
    $resultado['max_id'] = intval($max_result['max_id']);
    $resultado['next_id'] = $next_id;
    
    // 2. Verificar si el campo id es PRIMARY KEY
    $stmt_pk = $pdo->query("
        SELECT COLUMN_KEY 
        FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base' 
          AND COLUMN_NAME = 'id'
    ");
    $pk_info = $stmt_pk->fetch(PDO::FETCH_ASSOC);
    
    $resultado['id_es_primary_key'] = ($pk_info['COLUMN_KEY'] === 'PRI');
    
    // 3. Verificar si hay otros campos con AUTO_INCREMENT
    $stmt_otros = $pdo->query("
        SELECT COLUMN_NAME 
        FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base'
          AND EXTRA LIKE '%auto_increment%'
    ");
    $otros_auto = $stmt_otros->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($otros_auto) > 0) {
        $resultado['errores'][] = "Hay otros campos con AUTO_INCREMENT: " . json_encode($otros_auto);
    }
    
    // 4. Si el campo id NO es PRIMARY KEY, hacerlo PRIMARY KEY primero
    if ($pk_info['COLUMN_KEY'] !== 'PRI') {
        try {
            // Verificar si ya existe una PRIMARY KEY
            $stmt_existe_pk = $pdo->query("
                SELECT CONSTRAINT_NAME 
                FROM information_schema.TABLE_CONSTRAINTS 
                WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'carpeta_linea_base' 
                  AND CONSTRAINT_TYPE = 'PRIMARY KEY'
            ");
            $existe_pk = $stmt_existe_pk->fetch(PDO::FETCH_ASSOC);
            
            if ($existe_pk) {
                // Eliminar la PRIMARY KEY existente
                $pdo->exec("ALTER TABLE carpeta_linea_base DROP PRIMARY KEY");
                $resultado['acciones'][] = "PRIMARY KEY existente eliminada";
            }
            
            // Agregar PRIMARY KEY al campo id
            $pdo->exec("ALTER TABLE carpeta_linea_base ADD PRIMARY KEY (id)");
            $resultado['acciones'][] = "PRIMARY KEY agregada al campo id";
            
        } catch (Exception $e) {
            $resultado['errores'][] = "Error configurando PRIMARY KEY: " . $e->getMessage();
        }
    }
    
    // 5. Agregar AUTO_INCREMENT al campo id
    try {
        // Verificar estado actual
        $stmt_check = $pdo->query("
            SELECT EXTRA 
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
              AND TABLE_NAME = 'carpeta_linea_base' 
              AND COLUMN_NAME = 'id'
        ");
        $id_info = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($id_info && strpos($id_info['EXTRA'], 'auto_increment') === false) {
            // Agregar AUTO_INCREMENT
            $pdo->exec("ALTER TABLE carpeta_linea_base MODIFY id INT NOT NULL AUTO_INCREMENT");
            $resultado['acciones'][] = "AUTO_INCREMENT agregado al campo id";
            
            // Establecer el valor de AUTO_INCREMENT
            $pdo->exec("ALTER TABLE carpeta_linea_base AUTO_INCREMENT = $next_id");
            $resultado['acciones'][] = "AUTO_INCREMENT establecido a $next_id";
        } else {
            $resultado['acciones'][] = "AUTO_INCREMENT ya estaba configurado";
        }
    } catch (Exception $e) {
        $resultado['errores'][] = "Error agregando AUTO_INCREMENT: " . $e->getMessage();
    }
    
    // 6. Verificar estado final
    $stmt_final = $pdo->query("
        SELECT EXTRA, COLUMN_KEY 
        FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base' 
          AND COLUMN_NAME = 'id'
    ");
    $final = $stmt_final->fetch(PDO::FETCH_ASSOC);
    $resultado['estado_final'] = $final;
    
    // 7. Verificar AUTO_INCREMENT de la tabla
    $stmt_auto_tabla = $pdo->query("
        SELECT AUTO_INCREMENT 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base'
    ");
    $auto_tabla = $stmt_auto_tabla->fetch(PDO::FETCH_ASSOC);
    $resultado['auto_increment_tabla'] = $auto_tabla['AUTO_INCREMENT'];
    
    echo json_encode($resultado, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

