<?php
/**
 * Script COMPLETO para corregir carpeta_linea_base en producción
 * 1. Limpia duplicados (especialmente id=0)
 * 2. Agrega PRIMARY KEY
 * 3. Agrega AUTO_INCREMENT
 */

header('Content-Type: application/json; charset=utf-8');

if (ob_get_level()) {
    ob_clean();
}

require_once __DIR__ . '/config.php';

$dbConfig = getDbConfig();
$dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset=utf8mb4";
$username = $dbConfig['user'];
$password = $dbConfig['pass'];
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $username, $password, $options);
    
    $resultado = [
        'fecha' => date('Y-m-d H:i:s'),
        'paso' => 1,
        'acciones' => [],
        'errores' => [],
        'estadisticas' => []
    ];
    
    // PASO 1: Contar y limpiar registros con id=0
    $resultado['paso'] = 1;
    $resultado['paso_descripcion'] = 'Limpiando registros con id=0';
    
    $stmt_ceros = $pdo->query("SELECT COUNT(*) as total FROM carpeta_linea_base WHERE id = 0");
    $ceros_count = $stmt_ceros->fetch(PDO::FETCH_ASSOC);
    $total_ceros = intval($ceros_count['total']);
    
    $resultado['estadisticas']['registros_id_cero'] = $total_ceros;
    
    if ($total_ceros > 0) {
        // Obtener el máximo ID actual
        $stmt_max = $pdo->query("SELECT COALESCE(MAX(id), 0) as max_id FROM carpeta_linea_base WHERE id > 0");
        $max_result = $stmt_max->fetch(PDO::FETCH_ASSOC);
        $next_id = intval($max_result['max_id']) + 1;
        
        // Obtener todos los registros con id=0
        $stmt_ceros = $pdo->query("
            SELECT id, carpeta_id, control_preventivo_id, dimension, pregunta, evidencia, creado_en
            FROM carpeta_linea_base 
            WHERE id = 0
            ORDER BY creado_en DESC
        ");
        $ceros = $stmt_ceros->fetchAll(PDO::FETCH_ASSOC);
        
        // Agrupar por propiedades únicas
        $grupos = [];
        foreach ($ceros as $registro) {
            $key = md5(
                ($registro['carpeta_id'] ?? '') . '|' .
                ($registro['control_preventivo_id'] ?? '') . '|' .
                ($registro['dimension'] ?? '') . '|' .
                ($registro['pregunta'] ?? '') . '|' .
                ($registro['evidencia'] ?? '')
            );
            
            if (!isset($grupos[$key])) {
                $grupos[$key] = $registro;
            }
        }
        
        // Reasignar IDs únicos a los registros que vamos a mantener
        $pdo->beginTransaction();
        try {
            $ids_actualizados = 0;
            foreach ($grupos as $key => $registro) {
                $nuevo_id = $next_id++;
                
                $stmt_update = $pdo->prepare("
                    UPDATE carpeta_linea_base 
                    SET id = ? 
                    WHERE id = 0 
                      AND carpeta_id = ? 
                      AND (control_preventivo_id <=> ?)
                      AND (dimension <=> ?)
                      AND (pregunta <=> ?)
                      AND (evidencia <=> ?)
                    ORDER BY creado_en DESC
                    LIMIT 1
                ");
                $stmt_update->execute([
                    $nuevo_id,
                    $registro['carpeta_id'],
                    $registro['control_preventivo_id'],
                    $registro['dimension'],
                    $registro['pregunta'],
                    $registro['evidencia']
                ]);
                
                if ($stmt_update->rowCount() > 0) {
                    $ids_actualizados++;
                }
            }
            
            // Eliminar los registros que aún tienen id=0 (duplicados)
            $stmt_delete = $pdo->prepare("DELETE FROM carpeta_linea_base WHERE id = 0");
            $stmt_delete->execute();
            $eliminados = $stmt_delete->rowCount();
            
            $pdo->commit();
            
            $resultado['acciones'][] = "Reasignados $ids_actualizados registros con id=0 a IDs únicos";
            $resultado['acciones'][] = "Eliminados $eliminados registros duplicados con id=0";
            
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    } else {
        $resultado['acciones'][] = "No hay registros con id=0";
    }
    
    // PASO 2: Limpiar otros duplicados (IDs > 0)
    $resultado['paso'] = 2;
    $resultado['paso_descripcion'] = 'Limpiando otros duplicados';
    
    $stmt_dups = $pdo->query("
        SELECT id, COUNT(*) as cnt 
        FROM carpeta_linea_base 
        WHERE id > 0
        GROUP BY id 
        HAVING cnt > 1
        ORDER BY cnt DESC
    ");
    $duplicados = $stmt_dups->fetchAll(PDO::FETCH_ASSOC);
    
    $resultado['estadisticas']['duplicados_encontrados'] = count($duplicados);
    
    if (count($duplicados) > 0) {
        // Obtener el máximo ID actualizado
        $stmt_max = $pdo->query("SELECT COALESCE(MAX(id), 0) as max_id FROM carpeta_linea_base");
        $max_result = $stmt_max->fetch(PDO::FETCH_ASSOC);
        $next_id = intval($max_result['max_id']) + 1;
        
        foreach ($duplicados as $dup) {
            $id_dup = $dup['id'];
            
            // Obtener todos los registros con este ID
            $stmt_regs = $pdo->prepare("
                SELECT * FROM carpeta_linea_base 
                WHERE id = ? 
                ORDER BY creado_en DESC
            ");
            $stmt_regs->execute([$id_dup]);
            $registros = $stmt_regs->fetchAll(PDO::FETCH_ASSOC);
            
            // Mantener el primero, reasignar IDs a los demás
            if (count($registros) > 1) {
                $pdo->beginTransaction();
                try {
                    for ($i = 1; $i < count($registros); $i++) {
                        $nuevo_id = $next_id++;
                        $reg = $registros[$i];
                        
                        $stmt_update = $pdo->prepare("
                            UPDATE carpeta_linea_base 
                            SET id = ? 
                            WHERE id = ? 
                              AND carpeta_id = ? 
                              AND (control_preventivo_id <=> ?)
                              AND (dimension <=> ?)
                              AND (pregunta <=> ?)
                              AND (evidencia <=> ?)
                              AND creado_en = ?
                            LIMIT 1
                        ");
                        $stmt_update->execute([
                            $nuevo_id,
                            $id_dup,
                            $reg['carpeta_id'],
                            $reg['control_preventivo_id'],
                            $reg['dimension'],
                            $reg['pregunta'],
                            $reg['evidencia'],
                            $reg['creado_en']
                        ]);
                    }
                    
                    $pdo->commit();
                    $resultado['acciones'][] = "Reasignados " . (count($registros) - 1) . " registros duplicados con id=$id_dup";
                    
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $resultado['errores'][] = "Error procesando duplicados de id=$id_dup: " . $e->getMessage();
                }
            }
        }
    }
    
    // PASO 3: Agregar PRIMARY KEY
    $resultado['paso'] = 3;
    $resultado['paso_descripcion'] = 'Agregando PRIMARY KEY';
    
    $stmt_pk = $pdo->query("
        SELECT COLUMN_KEY 
        FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base' 
          AND COLUMN_NAME = 'id'
    ");
    $pk_info = $stmt_pk->fetch(PDO::FETCH_ASSOC);
    
    if ($pk_info['COLUMN_KEY'] !== 'PRI') {
        try {
            // Verificar si ya existe una PRIMARY KEY
            $stmt_existe_pk = $pdo->query("
                SELECT CONSTRAINT_NAME 
                FROM information_schema.TABLE_CONSTRAINTS 
                WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'carpeta_linea_base' 
                  AND CONSTRAINT_TYPE = 'PRIMARY KEY'
            ");
            $existe_pk = $stmt_existe_pk->fetch(PDO::FETCH_ASSOC);
            
            if ($existe_pk) {
                $pdo->exec("ALTER TABLE carpeta_linea_base DROP PRIMARY KEY");
                $resultado['acciones'][] = "PRIMARY KEY existente eliminada";
            }
            
            // Agregar PRIMARY KEY al campo id
            $pdo->exec("ALTER TABLE carpeta_linea_base ADD PRIMARY KEY (id)");
            $resultado['acciones'][] = "PRIMARY KEY agregada al campo id";
            
        } catch (Exception $e) {
            $resultado['errores'][] = "Error configurando PRIMARY KEY: " . $e->getMessage();
        }
    } else {
        $resultado['acciones'][] = "PRIMARY KEY ya estaba configurada";
    }
    
    // PASO 4: Agregar AUTO_INCREMENT
    $resultado['paso'] = 4;
    $resultado['paso_descripcion'] = 'Agregando AUTO_INCREMENT';
    
    // Obtener el máximo ID final
    $stmt_max_final = $pdo->query("SELECT COALESCE(MAX(id), 0) as max_id FROM carpeta_linea_base");
    $max_final = $stmt_max_final->fetch(PDO::FETCH_ASSOC);
    $next_id_final = intval($max_final['max_id']) + 1;
    
    try {
        $stmt_check = $pdo->query("
            SELECT EXTRA 
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
              AND TABLE_NAME = 'carpeta_linea_base' 
              AND COLUMN_NAME = 'id'
        ");
        $id_info = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if ($id_info && strpos($id_info['EXTRA'], 'auto_increment') === false) {
            // Agregar AUTO_INCREMENT
            $pdo->exec("ALTER TABLE carpeta_linea_base MODIFY id INT NOT NULL AUTO_INCREMENT");
            $resultado['acciones'][] = "AUTO_INCREMENT agregado al campo id";
            
            // Establecer el valor de AUTO_INCREMENT
            $pdo->exec("ALTER TABLE carpeta_linea_base AUTO_INCREMENT = $next_id_final");
            $resultado['acciones'][] = "AUTO_INCREMENT establecido a $next_id_final";
        } else {
            $resultado['acciones'][] = "AUTO_INCREMENT ya estaba configurado";
        }
    } catch (Exception $e) {
        $resultado['errores'][] = "Error agregando AUTO_INCREMENT: " . $e->getMessage();
    }
    
    // PASO 5: Verificar estado final
    $resultado['paso'] = 5;
    $resultado['paso_descripcion'] = 'Verificando estado final';
    
    $stmt_final = $pdo->query("
        SELECT EXTRA, COLUMN_KEY 
        FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base' 
          AND COLUMN_NAME = 'id'
    ");
    $final = $stmt_final->fetch(PDO::FETCH_ASSOC);
    $resultado['estado_final'] = $final;
    
    $stmt_auto_tabla = $pdo->query("
        SELECT AUTO_INCREMENT 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = DATABASE() 
          AND TABLE_NAME = 'carpeta_linea_base'
    ");
    $auto_tabla = $stmt_auto_tabla->fetch(PDO::FETCH_ASSOC);
    $resultado['auto_increment_tabla'] = $auto_tabla['AUTO_INCREMENT'];
    
    // Verificar que no hay duplicados
    $stmt_verif = $pdo->query("
        SELECT COUNT(*) as total, COUNT(DISTINCT id) as unicos
        FROM carpeta_linea_base
    ");
    $verif = $stmt_verif->fetch(PDO::FETCH_ASSOC);
    $resultado['estadisticas']['verificacion_final'] = [
        'total_registros' => intval($verif['total']),
        'ids_unicos' => intval($verif['unicos']),
        'sin_duplicados' => (intval($verif['total']) === intval($verif['unicos']))
    ];
    
    echo json_encode($resultado, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Error: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString(),
        'paso' => $resultado['paso'] ?? 'desconocido',
        'paso_descripcion' => $resultado['paso_descripcion'] ?? 'desconocido'
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

