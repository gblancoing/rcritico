<?php
// Este archivo se incluye cuando TCPDF no está disponible
// Genera un HTML que se puede imprimir como PDF desde el navegador
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte del Proyecto: <?php echo htmlspecialchars($proyecto['nombre']); ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @media print {
            @page {
                size: A4;
                margin: 1cm;
            }
            body {
                margin: 0;
                padding: 10px;
            }
            .no-print {
                display: none !important;
            }
            .page-break {
                page-break-after: always;
            }
            .section {
                page-break-inside: avoid;
            }
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #1a1a1a;
            line-height: 1.7;
            background: #f5f7fa;
            padding: 20px;
        }
        
        .container {
            max-width: 210mm;
            margin: 0 auto;
            background: #ffffff;
            box-shadow: 0 0 30px rgba(0,0,0,0.1);
        }
        
        /* Portada */
        .cover-page {
            background: linear-gradient(135deg, #002B7F 0%, #0a6ebd 50%, #005288 100%);
            color: white;
            padding: 60px 40px;
            text-align: center;
            min-height: 297mm;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
        }
        
        .cover-page::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .cover-content {
            position: relative;
            z-index: 1;
        }
        
        .cover-logo {
            font-size: 72px;
            font-weight: 800;
            letter-spacing: 8px;
            margin-bottom: 20px;
            text-shadow: 2px 2px 10px rgba(0,0,0,0.3);
        }
        
        .cover-subtitle {
            font-size: 18px;
            font-weight: 300;
            letter-spacing: 3px;
            margin-bottom: 60px;
            opacity: 0.95;
        }
        
        .cover-title {
            font-size: 36px;
            font-weight: 700;
            margin: 40px 0 30px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .cover-project {
            font-size: 28px;
            font-weight: 600;
            margin: 20px 0;
            color: #F2A900;
        }
        
        .cover-meta {
            margin-top: 80px;
            font-size: 14px;
            opacity: 0.9;
        }
        
        /* Secciones */
        .section {
            padding: 40px;
            margin-bottom: 20px;
            background: white;
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 700;
            color: #002B7F;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 4px solid #F2A900;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title i {
            font-size: 28px;
            color: #F2A900;
        }
        
        /* KPIs Cards */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .kpi-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border: 1px solid #e9ecef;
            border-left: 5px solid #0a6ebd;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .kpi-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        }
        
        .kpi-card.primary { border-left-color: #0a6ebd; }
        .kpi-card.success { border-left-color: #28a745; }
        .kpi-card.warning { border-left-color: #ffc107; }
        .kpi-card.danger { border-left-color: #dc3545; }
        .kpi-card.info { border-left-color: #17a2b8; }
        .kpi-card.orange { border-left-color: #fd7e14; }
        
        .kpi-icon {
            font-size: 32px;
            margin-bottom: 15px;
            opacity: 0.8;
        }
        
        .kpi-label {
            font-size: 13px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .kpi-value {
            font-size: 36px;
            font-weight: 800;
            color: #1a1a1a;
            line-height: 1;
        }
        
        .kpi-value small {
            font-size: 20px;
            font-weight: 600;
            color: #6c757d;
        }
        
        /* Gráficos */
        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin: 30px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .chart-title {
            font-size: 18px;
            font-weight: 600;
            color: #002B7F;
            margin-bottom: 20px;
            text-align: center;
        }
        
        /* Progress Bars */
        .progress-container {
            margin: 20px 0;
        }
        
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
            color: #495057;
        }
        
        .progress-bar-wrapper {
            height: 28px;
            background: #e9ecef;
            border-radius: 14px;
            overflow: hidden;
            position: relative;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #0a6ebd 0%, #17a2b8 100%);
            border-radius: 14px;
            transition: width 1s ease;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 12px;
            color: white;
            font-weight: 700;
            font-size: 12px;
            position: relative;
            overflow: hidden;
        }
        
        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .progress-bar.success { background: linear-gradient(90deg, #28a745 0%, #20c997 100%); }
        .progress-bar.warning { background: linear-gradient(90deg, #ffc107 0%, #ff9800 100%); }
        .progress-bar.danger { background: linear-gradient(90deg, #dc3545 0%, #c82333 100%); }
        
        /* Tablas */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        table thead {
            background: linear-gradient(135deg, #002B7F 0%, #0a6ebd 100%);
            color: white;
        }
        
        table th {
            padding: 16px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        table td {
            padding: 14px 16px;
            border-bottom: 1px solid #e9ecef;
            font-size: 14px;
        }
        
        table tbody tr {
            transition: background 0.2s ease;
        }
        
        table tbody tr:hover {
            background: #f8f9fa;
        }
        
        table tbody tr:last-child td {
            border-bottom: none;
        }
        
        /* Badges */
        .badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        
        .badge-warning {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
            color: #1a1a1a;
        }
        
        .badge-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
        }
        
        /* Info Box */
        .info-box {
            background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
            border-left: 5px solid #0a6ebd;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
        }
        
        .info-box h4 {
            color: #002B7F;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .info-box p {
            color: #495057;
            font-size: 14px;
            margin: 5px 0;
        }
        
        /* Print Button */
        .print-button {
            position: fixed;
            top: 30px;
            right: 30px;
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 700;
            box-shadow: 0 4px 16px rgba(220, 53, 69, 0.4);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .print-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(220, 53, 69, 0.5);
        }
        
        /* Footer */
        .footer {
            background: #f8f9fa;
            padding: 30px 40px;
            text-align: center;
            border-top: 3px solid #e9ecef;
            color: #6c757d;
            font-size: 12px;
        }
        
        .footer p {
            margin: 5px 0;
        }
        
        /* Circular Progress */
        .circular-progress {
            width: 120px;
            height: 120px;
            margin: 20px auto;
            position: relative;
        }
        
        .circular-progress svg {
            transform: rotate(-90deg);
        }
        
        .circular-progress .bg {
            fill: none;
            stroke: #e9ecef;
            stroke-width: 8;
        }
        
        .circular-progress .progress {
            fill: none;
            stroke-width: 8;
            stroke-linecap: round;
            transition: stroke-dashoffset 1s ease;
        }
        
        .circular-progress .progress.success { stroke: #28a745; }
        .circular-progress .progress.warning { stroke: #ffc107; }
        .circular-progress .progress.danger { stroke: #dc3545; }
        .circular-progress .progress.info { stroke: #0a6ebd; }
        
        .circular-progress .text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 24px;
            font-weight: 800;
            color: #1a1a1a;
        }
        
        .circular-progress .label {
            position: absolute;
            bottom: -30px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 12px;
            color: #6c757d;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <button class="print-button no-print" onclick="window.print()">
        <i class="fas fa-print"></i> Imprimir / Guardar como PDF
    </button>

    <div class="container">
        <!-- Portada -->
        <div class="cover-page page-break">
            <div class="cover-content">
                <div class="cover-logo">CODELCO</div>
                <div class="cover-subtitle">Sistema de Control de Riesgos Críticos</div>
                <div class="cover-title">Reporte Completo del Proyecto</div>
                <div class="cover-project"><?php echo htmlspecialchars($proyecto['nombre']); ?></div>
                <div class="cover-meta">
                    <p style="font-size: 16px; margin: 10px 0;">ID Proyecto: <?php echo $proyecto['proyecto_id']; ?></p>
                    <p style="font-size: 14px; margin: 10px 0;">Generado el: <?php echo date('d/m/Y H:i:s'); ?></p>
                    <?php if (isset($proyecto['descripcion']) && $proyecto['descripcion']): ?>
                    <p style="font-size: 13px; margin-top: 20px; opacity: 0.85; max-width: 600px; margin-left: auto; margin-right: auto;">
                        <?php echo htmlspecialchars($proyecto['descripcion']); ?>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Resumen Ejecutivo -->
        <div class="section page-break">
            <div class="section-title">
                <i class="fas fa-chart-line"></i>
                RESUMEN EJECUTIVO
            </div>
            
            <div class="info-box">
                <h4><i class="fas fa-info-circle"></i> Información del Proyecto</h4>
                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($proyecto['nombre']); ?></p>
                <p><strong>ID:</strong> <?php echo $proyecto['proyecto_id']; ?></p>
                <?php if (isset($proyecto['descripcion']) && $proyecto['descripcion']): ?>
                <p><strong>Descripción:</strong> <?php echo htmlspecialchars($proyecto['descripcion']); ?></p>
                <?php endif; ?>
            </div>
            
            <h3 style="margin: 30px 0 20px; color: #002B7F; font-size: 20px;">Indicadores Clave de Desempeño (KPIs)</h3>
            
            <div class="kpi-grid">
                <div class="kpi-card primary">
                    <div class="kpi-icon"><i class="fas fa-chart-pie"></i></div>
                    <div class="kpi-label">Avance General</div>
                    <div class="kpi-value"><?php echo number_format($promedio_general, 2); ?><small>%</small></div>
                </div>
                <div class="kpi-card info">
                    <div class="kpi-icon"><i class="fas fa-folder"></i></div>
                    <div class="kpi-label">Total Carpetas</div>
                    <div class="kpi-value"><?php echo number_format($kpis['total_carpetas'] ?? 0); ?></div>
                </div>
                <div class="kpi-card success">
                    <div class="kpi-icon"><i class="fas fa-shield-alt"></i></div>
                    <div class="kpi-label">Total Controles</div>
                    <div class="kpi-value"><?php echo number_format($kpis['total_controles'] ?? 0); ?></div>
                </div>
                <div class="kpi-card success">
                    <div class="kpi-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="kpi-label">Controles Validados</div>
                    <div class="kpi-value"><?php echo number_format($kpis['controles_validados'] ?? 0); ?></div>
                </div>
                <div class="kpi-card warning">
                    <div class="kpi-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="kpi-label">Con Observaciones</div>
                    <div class="kpi-value"><?php echo number_format($kpis['controles_observaciones'] ?? 0); ?></div>
                </div>
                <div class="kpi-card info">
                    <div class="kpi-icon"><i class="fas fa-users"></i></div>
                    <div class="kpi-label">Usuarios Activos</div>
                    <div class="kpi-value"><?php echo number_format($kpis['usuarios_activos'] ?? 0); ?></div>
                </div>
                <div class="kpi-card orange">
                    <div class="kpi-icon"><i class="fas fa-building"></i></div>
                    <div class="kpi-label">Avance Global por Empresa</div>
                    <div class="kpi-value"><?php echo number_format($kpis['avance_global_empresas'] ?? 0, 2); ?><small>%</small></div>
                </div>
            </div>
            
            <!-- Gráfico de Avance General -->
            <div class="chart-container">
                <div class="chart-title">Avance General del Proyecto</div>
                <div class="circular-progress">
                    <svg width="120" height="120">
                        <circle class="bg" cx="60" cy="60" r="52"></circle>
                        <circle class="progress <?php 
                            $class = 'danger';
                            if ($promedio_general >= 80) $class = 'success';
                            elseif ($promedio_general >= 50) $class = 'warning';
                            echo $class;
                        ?>" cx="60" cy="60" r="52" 
                        stroke-dasharray="<?php echo 2 * M_PI * 52; ?>" 
                        stroke-dashoffset="<?php echo 2 * M_PI * 52 * (1 - $promedio_general / 100); ?>"></circle>
                    </svg>
                    <div class="text"><?php echo number_format($promedio_general, 1); ?>%</div>
                    <div class="label">Avance</div>
                </div>
            </div>
            
            <!-- Gráfico de Barras para KPIs -->
            <?php 
            $total_controles = $kpis['total_controles'] ?? 0;
            $controles_validados = $kpis['controles_validados'] ?? 0;
            $controles_observaciones = $kpis['controles_observaciones'] ?? 0;
            $controles_pendientes = $total_controles - $controles_validados - $controles_observaciones;
            ?>
            <div class="chart-container">
                <div class="chart-title">Estado de los Controles</div>
                <canvas id="controlesChart" height="80"></canvas>
            </div>
        </div>

        <!-- Avance por Empresa -->
        <?php if (!empty($kpis['avance_por_empresa']) && is_array($kpis['avance_por_empresa'])): ?>
        <div class="section page-break">
            <div class="section-title">
                <i class="fas fa-building"></i>
                AVANCE POR EMPRESA
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th><i class="fas fa-building"></i> Empresa</th>
                        <th><i class="fas fa-chart-line"></i> Avance</th>
                        <th><i class="fas fa-shield-alt"></i> Controles</th>
                        <th><i class="fas fa-tasks"></i> Progreso</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kpis['avance_por_empresa'] as $empresa): 
                        $avance = floatval($empresa['avance_promedio'] ?? 0);
                        $badge_class = $avance >= 80 ? 'badge-success' : ($avance >= 50 ? 'badge-warning' : 'badge-danger');
                        $progress_class = $avance >= 80 ? 'success' : ($avance >= 50 ? 'warning' : 'danger');
                    ?>
                    <tr>
                        <td style="font-weight: 600;"><?php echo htmlspecialchars($empresa['empresa'] ?? 'Sin nombre'); ?></td>
                        <td>
                            <span class="badge <?php echo $badge_class; ?>">
                                <?php echo number_format($avance, 1); ?>%
                            </span>
                        </td>
                        <td><?php echo number_format($empresa['total_controles'] ?? 0); ?></td>
                        <td>
                            <div class="progress-container">
                                <div class="progress-bar-wrapper">
                                    <div class="progress-bar <?php echo $progress_class; ?>" style="width: <?php echo $avance; ?>%;">
                                        <?php echo number_format($avance, 1); ?>%
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Gráfico de Empresas -->
            <div class="chart-container">
                <div class="chart-title">Comparativa de Avance por Empresa</div>
                <canvas id="empresasChart" height="60"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <!-- Avance por RC -->
        <?php if (!empty($carpetas_data['carpetas']) && is_array($carpetas_data['carpetas'])): ?>
            <?php foreach ($carpetas_data['carpetas'] as $carpeta_nivel1): ?>
            <div class="section page-break">
                <div class="section-title">
                    <i class="fas fa-exclamation-triangle"></i>
                    RIESGO CRÍTICO: <?php echo strtoupper(htmlspecialchars($carpeta_nivel1['nombre'])); ?>
                </div>
                
                <?php 
                $promedio_rc = floatval($carpeta_nivel1['promedio_ponderacion'] ?? 0);
                $badge_class_rc = $promedio_rc >= 80 ? 'badge-success' : ($promedio_rc >= 50 ? 'badge-warning' : 'badge-danger');
                $progress_class_rc = $promedio_rc >= 80 ? 'success' : ($promedio_rc >= 50 ? 'warning' : 'danger');
                ?>
                
                <div class="info-box">
                    <h4><i class="fas fa-chart-pie"></i> Avance del Riesgo Crítico</h4>
                    <div style="display: flex; align-items: center; gap: 20px; margin-top: 15px;">
                        <div class="circular-progress" style="width: 100px; height: 100px;">
                            <svg width="100" height="100">
                                <circle class="bg" cx="50" cy="50" r="42"></circle>
                                <circle class="progress <?php echo $progress_class_rc; ?>" cx="50" cy="50" r="42" 
                                stroke-dasharray="<?php echo 2 * M_PI * 42; ?>" 
                                stroke-dashoffset="<?php echo 2 * M_PI * 42 * (1 - $promedio_rc / 100); ?>"></circle>
                            </svg>
                            <div class="text" style="font-size: 20px;"><?php echo number_format($promedio_rc, 1); ?>%</div>
                        </div>
                        <div>
                            <p style="font-size: 18px; font-weight: 700; color: #002B7F; margin-bottom: 10px;">
                                <span class="badge <?php echo $badge_class_rc; ?>" style="font-size: 16px; padding: 8px 16px;">
                                    <?php echo number_format($promedio_rc, 2); ?>%
                                </span>
                            </p>
                            <div class="progress-container" style="width: 300px;">
                                <div class="progress-bar-wrapper">
                                    <div class="progress-bar <?php echo $progress_class_rc; ?>" style="width: <?php echo $promedio_rc; ?>%;">
                                        <?php echo number_format($promedio_rc, 1); ?>%
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (!empty($carpeta_nivel1['subcarpetas']) && is_array($carpeta_nivel1['subcarpetas'])): ?>
                <h4 style="margin: 30px 0 15px; color: #002B7F; font-size: 18px;">
                    <i class="fas fa-building"></i> Empresas Asociadas
                </h4>
                <table>
                    <thead>
                        <tr>
                            <th><i class="fas fa-building"></i> Empresa</th>
                            <th><i class="fas fa-chart-line"></i> Avance</th>
                            <th><i class="fas fa-tasks"></i> Progreso</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($carpeta_nivel1['subcarpetas'] as $subcarpeta): 
                            $avance_emp = floatval($subcarpeta['promedio_ponderacion'] ?? 0);
                            $badge_class_emp = $avance_emp >= 80 ? 'badge-success' : ($avance_emp >= 50 ? 'badge-warning' : 'badge-danger');
                            $progress_class_emp = $avance_emp >= 80 ? 'success' : ($avance_emp >= 50 ? 'warning' : 'danger');
                        ?>
                        <tr>
                            <td style="font-weight: 600;"><?php echo htmlspecialchars($subcarpeta['nombre'] ?? 'Sin nombre'); ?></td>
                            <td>
                                <span class="badge <?php echo $badge_class_emp; ?>">
                                    <?php echo number_format($avance_emp, 2); ?>%
                                </span>
                            </td>
                            <td>
                                <div class="progress-container">
                                    <div class="progress-bar-wrapper">
                                        <div class="progress-bar <?php echo $progress_class_emp; ?>" style="width: <?php echo $avance_emp; ?>%;">
                                            <?php echo number_format($avance_emp, 1); ?>%
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- Footer -->
        <div class="footer">
            <p style="font-weight: 700; color: #002B7F; margin-bottom: 10px;">
                <i class="fas fa-shield-alt"></i> Sistema de Control de Riesgos Críticos
            </p>
            <p>Este reporte fue generado automáticamente por el Sistema de Control de Riesgos Críticos de Codelco.</p>
            <p>Para más información, contacte al administrador del sistema.</p>
            <p style="margin-top: 15px; font-weight: 600;">Fecha de generación: <?php echo date('d/m/Y H:i:s'); ?></p>
        </div>
    </div>

    <script>
        // Gráfico de Estado de Controles
        const controlesCtx = document.getElementById('controlesChart');
        if (controlesCtx) {
            new Chart(controlesCtx, {
                type: 'bar',
                data: {
                    labels: ['Validados', 'Con Observaciones', 'Pendientes'],
                    datasets: [{
                        label: 'Cantidad de Controles',
                        data: [
                            <?php echo $controles_validados; ?>,
                            <?php echo $controles_observaciones; ?>,
                            <?php echo max(0, $controles_pendientes); ?>
                        ],
                        backgroundColor: [
                            'rgba(40, 167, 69, 0.8)',
                            'rgba(255, 193, 7, 0.8)',
                            'rgba(220, 53, 69, 0.8)'
                        ],
                        borderColor: [
                            'rgba(40, 167, 69, 1)',
                            'rgba(255, 193, 7, 1)',
                            'rgba(220, 53, 69, 1)'
                        ],
                        borderWidth: 2,
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            titleFont: { size: 14, weight: 'bold' },
                            bodyFont: { size: 13 }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    }
                }
            });
        }

        // Gráfico de Empresas
        const empresasCtx = document.getElementById('empresasChart');
        if (empresasCtx && <?php echo !empty($kpis['avance_por_empresa']) ? 'true' : 'false'; ?>) {
            const empresasData = <?php echo json_encode(array_map(function($e) { 
                return ['nombre' => $e['empresa'] ?? 'Sin nombre', 'avance' => floatval($e['avance_promedio'] ?? 0)]; 
            }, $kpis['avance_por_empresa'])); ?>;
            
            new Chart(empresasCtx, {
                type: 'bar',
                data: {
                    labels: empresasData.map(e => e.nombre),
                    datasets: [{
                        label: 'Avance (%)',
                        data: empresasData.map(e => e.avance),
                        backgroundColor: empresasData.map(e => {
                            if (e.avance >= 80) return 'rgba(40, 167, 69, 0.8)';
                            if (e.avance >= 50) return 'rgba(255, 193, 7, 0.8)';
                            return 'rgba(220, 53, 69, 0.8)';
                        }),
                        borderColor: empresasData.map(e => {
                            if (e.avance >= 80) return 'rgba(40, 167, 69, 1)';
                            if (e.avance >= 50) return 'rgba(255, 193, 7, 1)';
                            return 'rgba(220, 53, 69, 1)';
                        }),
                        borderWidth: 2,
                        borderRadius: 8
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            titleFont: { size: 14, weight: 'bold' },
                            bodyFont: { size: 13 },
                            callbacks: {
                                label: function(context) {
                                    return 'Avance: ' + context.parsed.x.toFixed(1) + '%';
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                                callback: function(value) {
                                    return value + '%';
                                }
                            }
                        }
                    }
                }
            });
        }

        // Auto-imprimir si se solicita
        if (window.location.search.includes('autoprint=1')) {
            window.onload = function() {
                setTimeout(() => window.print(), 500);
            };
        }
    </script>
</body>
</html>
