<?php
// Redirección para mantener compatibilidad con rutas antiguas
require_once __DIR__ . '/proyectos/regiones.php';
?>

