<?php
// Este archivo se incluye cuando TCPDF no está disponible
// Genera un HTML que se puede imprimir como PDF desde el navegador
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte del Proyecto: <?php echo htmlspecialchars($proyecto['nombre']); ?></title>
    <style>
        @media print {
            @page {
                size: A4;
                margin: 1.5cm;
            }
            body {
                margin: 0;
            }
            .no-print {
                display: none;
            }
        }
        body {
            font-family: 'Arial', sans-serif;
            color: #333;
            line-height: 1.6;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #0a6ebd 0%, #005288 100%);
            color: white;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            margin: 0;
            font-size: 32px;
            font-weight: bold;
        }
        .header h2 {
            margin: 10px 0 0 0;
            font-size: 18px;
            font-weight: normal;
        }
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        .section-title {
            background: #0a6ebd;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        .kpi-card {
            border: 2px solid #e9ecef;
            border-left: 4px solid #0a6ebd;
            padding: 15px;
            border-radius: 8px;
            background: #f8f9fa;
        }
        .kpi-label {
            font-size: 12px;
            color: #6c757d;
            margin-bottom: 5px;
        }
        .kpi-value {
            font-size: 24px;
            font-weight: bold;
            color: #0a6ebd;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th {
            background: #f8f9fa;
            padding: 10px;
            text-align: left;
            border: 1px solid #dee2e6;
            font-weight: bold;
        }
        table td {
            padding: 8px 10px;
            border: 1px solid #dee2e6;
        }
        table tr:nth-child(even) {
            background: #f8f9fa;
        }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-success {
            background: #d4edda;
            color: #155724;
        }
        .badge-warning {
            background: #fff3cd;
            color: #856404;
        }
        .badge-danger {
            background: #f8d7da;
            color: #721c24;
        }
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc3545;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            z-index: 1000;
        }
        .print-button:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <button class="print-button no-print" onclick="window.print()">
        <i class="fa fa-print"></i> Imprimir / Guardar como PDF
    </button>

    <!-- Portada -->
    <div class="header">
        <h1>CODELCO</h1>
        <h2>Sistema de Control de Riesgos Críticos</h2>
        <h1 style="font-size: 24px; margin-top: 30px;">REPORTE COMPLETO DEL PROYECTO</h1>
        <h2 style="font-size: 20px; margin-top: 20px;"><?php echo htmlspecialchars($proyecto['nombre']); ?></h2>
        <p style="margin-top: 30px; font-size: 14px;">Generado el: <?php echo date('d/m/Y H:i:s'); ?></p>
        <p style="font-size: 12px;">ID Proyecto: <?php echo $proyecto['proyecto_id']; ?></p>
    </div>

    <!-- Resumen Ejecutivo -->
    <div class="section">
        <div class="section-title">RESUMEN EJECUTIVO</div>
        
        <h3>Información del Proyecto</h3>
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($proyecto['nombre']); ?></p>
        <p><strong>ID:</strong> <?php echo $proyecto['proyecto_id']; ?></p>
        <?php if (isset($proyecto['descripcion']) && $proyecto['descripcion']): ?>
        <p><strong>Descripción:</strong> <?php echo htmlspecialchars($proyecto['descripcion']); ?></p>
        <?php endif; ?>
        
        <h3 style="margin-top: 20px;">Indicadores Clave de Desempeño (KPIs)</h3>
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-label">Avance General</div>
                <div class="kpi-value"><?php echo number_format($promedio_general, 2); ?>%</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Total Carpetas</div>
                <div class="kpi-value"><?php echo $kpis['total_carpetas'] ?? 0; ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Total Controles</div>
                <div class="kpi-value"><?php echo $kpis['total_controles'] ?? 0; ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Controles Validados</div>
                <div class="kpi-value"><?php echo $kpis['controles_validados'] ?? 0; ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Controles con Observaciones</div>
                <div class="kpi-value"><?php echo $kpis['controles_observaciones'] ?? 0; ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Usuarios Activos</div>
                <div class="kpi-value"><?php echo $kpis['usuarios_activos'] ?? 0; ?></div>
            </div>
            <div class="kpi-card">
                <div class="kpi-label">Avance Global por Empresa</div>
                <div class="kpi-value"><?php echo number_format($kpis['avance_global_empresas'] ?? 0, 2); ?>%</div>
            </div>
        </div>
    </div>

    <!-- Avance por Empresa -->
    <?php if (!empty($kpis['avance_por_empresa']) && is_array($kpis['avance_por_empresa'])): ?>
    <div class="section">
        <div class="section-title" style="background: #fd7e14;">AVANCE POR EMPRESA</div>
        <table>
            <thead>
                <tr>
                    <th>Empresa</th>
                    <th>Avance</th>
                    <th>Controles</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($kpis['avance_por_empresa'] as $empresa): 
                    $avance = floatval($empresa['avance_promedio'] ?? 0);
                    $badge_class = $avance >= 80 ? 'badge-success' : ($avance >= 50 ? 'badge-warning' : 'badge-danger');
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($empresa['empresa'] ?? 'Sin nombre'); ?></td>
                    <td>
                        <span class="badge <?php echo $badge_class; ?>">
                            <?php echo number_format($avance, 1); ?>%
                        </span>
                    </td>
                    <td><?php echo $empresa['total_controles'] ?? 0; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <!-- Avance por RC -->
    <?php if (!empty($carpetas_data['carpetas']) && is_array($carpetas_data['carpetas'])): ?>
        <?php foreach ($carpetas_data['carpetas'] as $carpeta_nivel1): ?>
        <div class="section">
            <div class="section-title">RIESGO CRÍTICO: <?php echo strtoupper(htmlspecialchars($carpeta_nivel1['nombre'])); ?></div>
            
            <?php 
            $promedio_rc = floatval($carpeta_nivel1['promedio_ponderacion'] ?? 0);
            $badge_class_rc = $promedio_rc >= 80 ? 'badge-success' : ($promedio_rc >= 50 ? 'badge-warning' : 'badge-danger');
            ?>
            <p><strong>Avance del Riesgo Crítico:</strong> 
                <span class="badge <?php echo $badge_class_rc; ?>">
                    <?php echo number_format($promedio_rc, 2); ?>%
                </span>
            </p>
            
            <?php if (!empty($carpeta_nivel1['subcarpetas']) && is_array($carpeta_nivel1['subcarpetas'])): ?>
            <h4>Empresas Asociadas:</h4>
            <table>
                <thead>
                    <tr>
                        <th>Empresa</th>
                        <th>Avance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($carpeta_nivel1['subcarpetas'] as $subcarpeta): 
                        $avance_emp = floatval($subcarpeta['promedio_ponderacion'] ?? 0);
                        $badge_class_emp = $avance_emp >= 80 ? 'badge-success' : ($avance_emp >= 50 ? 'badge-warning' : 'badge-danger');
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($subcarpeta['nombre'] ?? 'Sin nombre'); ?></td>
                        <td>
                            <span class="badge <?php echo $badge_class_emp; ?>">
                                <?php echo number_format($avance_emp, 2); ?>%
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Pie de página -->
    <div class="section" style="margin-top: 50px; padding-top: 20px; border-top: 2px solid #dee2e6;">
        <p style="text-align: center; color: #6c757d; font-size: 12px;">
            Este reporte fue generado automáticamente por el Sistema de Control de Riesgos Críticos de Codelco.<br>
            Para más información, contacte al administrador del sistema.<br>
            Fecha de generación: <?php echo date('d/m/Y H:i:s'); ?>
        </p>
    </div>

    <script>
        // Auto-imprimir si se solicita
        if (window.location.search.includes('autoprint=1')) {
            window.onload = function() {
                window.print();
            };
        }
    </script>
</body>
</html>

